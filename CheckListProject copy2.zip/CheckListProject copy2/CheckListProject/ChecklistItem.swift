

import Foundation
class ChecklistItem: NSObject , Codable{
    
    var text = ""
    var date=""
    var checked = false
    
    var rDate:Date?
    var uuid = NSUUID().uuidString
    
    func toggleChecked() {
        checked = !checked
    }
    
}
