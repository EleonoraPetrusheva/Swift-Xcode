

import UIKit
import UserNotifications

class ChecklistViewController: UITableViewController,
itemDetailViewControllerDelegate {
    
   
    
    
    
    var items = [ChecklistItem]()
    
    var sections = ["High priority","Medium priority", "Low priority"]
    
    var highPr = [ChecklistItem]()
    var mediumPr = [ChecklistItem]()
    var lowPr = [ChecklistItem]()
    
    var countedIndex = 0
    let notificationCenter = UNUserNotificationCenter.current()
    let options: UNAuthorizationOptions = [.alert, .sound, .badge]
    
    
   
    fileprivate func setUpNotification(forEvent event:ChecklistItem){
        
        let content = UNMutableNotificationContent()
        content.title = "Your item\(event.text)"
        content.body = " Please complete it"
        
        if let date = event.rDate {
            
            let nextTriggerDate = Calendar.current.date(byAdding: .second, value: 0, to: date)!
            let comps = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: nextTriggerDate)
            
            let trigger = UNCalendarNotificationTrigger(dateMatching: comps,  repeats: false)
            print(comps)
            let request = UNNotificationRequest(identifier: event.uuid, content: content, trigger: trigger)
            UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
            
            
        }
        
        
        
        
    }
   
    fileprivate func removeLocalNotificationIfIsMarked() {
        
        var identifiers = [String]()
        
        for high in highPr{
            if high.checked == true {identifiers.append(high.uuid)}
        }
        for med in mediumPr{
            
            if med.checked == true {identifiers.append(med.uuid)}
            

        }
        for low in lowPr{
            if low.checked == true
            {identifiers.append(low.uuid)}
            
        }
        
        notificationCenter.removePendingNotificationRequests(withIdentifiers: identifiers)
        
        
        
    }
 

    
    
    //Mark-  Delegate
    func itemDetailViewControllerDidCancel(_ controller: ItemDetailViewController) {
        navigationController?.popViewController(animated: true)
    }
    
    func itemDetailViewController(_ controller: ItemDetailViewController,
                                  didFInishAdding item: ChecklistItem) {
        
        setUpNotification(forEvent: item)
        
        let newRowIndex = mediumPr.count
        mediumPr.append(item)
        items.append(item)
        let indexPath = IndexPath(row: newRowIndex, section: 1)
        let indexPaths = [indexPath]
        
        tableView.insertRows(at: indexPaths, with: .automatic)
        navigationController?.popViewController(animated: true)
        
        saveChecklistItemsLowPriority()
        saveChecklistItemsMediumPriority()
        saveChecklistItemsHighPriority()
        saveChecklistItemsCount()
    }
    
    
    func itemDetailViewController(_ controller: ItemDetailViewController,
                                  didFinishEditing item: ChecklistItem) {
        
        
        
        if let index = highPr.index(of: item) {
            let indexPath = IndexPath(row: index, section: 0)
            if let cell = tableView.cellForRow(at: indexPath) {
                configureText(for: cell, with: item)
            }
        }
        if let index1 = mediumPr.index(of: item) {
            let indexPath = IndexPath(row: index1, section: 1)
            if let cell = tableView.cellForRow(at: indexPath) {
                configureText(for: cell, with: item)
            }
        }
        if let index2 = lowPr.index(of: item) {
            let indexPath = IndexPath(row: index2, section: 2)
            if let cell = tableView.cellForRow(at: indexPath) {
                configureText(for: cell, with: item)
            }
        }
        
        
        navigationController?.popViewController(animated: true)
        saveChecklistItemsLowPriority()
        saveChecklistItemsMediumPriority()
        saveChecklistItemsHighPriority()
        saveChecklistItemsCount()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.allowsMultipleSelectionDuringEditing = true
        if #available(iOS 11.0, *) {
            navigationController?.navigationBar.prefersLargeTitles = true
        } else {
            // Fallback on earlier versions
        }

        
    
        notificationCenter.requestAuthorization(options: options){(_, _)in}
        self.tableView.dataSource = self
        self.tableView.delegate = self
        print("Documents folder is \(documentsDirectory())")
        
        
        
        loadChecklistItemsMediumPriority()
        loadChecklistItemsLowPriority()
        loadChecklistItemsHighPriority()
        loadChecklistItemsCount()
        
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        tableView.reloadData()
    }
    
    
    
   
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 3
        
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return sections[section]
    }
    
   
    
    
    
   
    
    override func tableView(_ tableView: UITableView,
                            numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return highPr.count
        } else if section == 1 {
            return mediumPr.count
        } else  {
            return lowPr.count
        }
        
        
        
    }
    
    override func tableView(_ tableView: UITableView,
                            cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell  = tableView.dequeueReusableCell(withIdentifier: "ChecklistItem",
                                                  for: indexPath)
        let item: ChecklistItem
        if indexPath.section == 0 {
            item = highPr[indexPath.row]
            
        } else if indexPath.section == 2 {
            item = lowPr[indexPath.row]
            
        } else
        {
            item = mediumPr[indexPath.row]
            
            
        }

        configureText(for: cell, with: item)
        configureCheckmark(for: cell, with: item)
        
        
        saveChecklistItemsHighPriority()
        saveChecklistItemsMediumPriority()
        saveChecklistItemsLowPriority()
        saveChecklistItemsCount()
        
        
        return cell
        
    }
    
    
    
    override func tableView(_ tableView: UITableView,
                            didSelectRowAt indexPath: IndexPath) {
        
        guard !tableView.isEditing else { return }
        
        if let cell = tableView.cellForRow(at: indexPath) {
            if indexPath.section == 0 {
                let item = highPr[indexPath.row]
                item.toggleChecked()
                configureCheckmark(for: cell, with: item)
            }
            else if indexPath.section == 2 {
                let item = lowPr[indexPath.row]
                item.toggleChecked()
                configureCheckmark(for: cell, with: item)
            } else{
                let item = mediumPr[indexPath.row]
                item.toggleChecked()
                configureCheckmark(for: cell, with: item)
                
            }
        }
        tableView.deselectRow(at: indexPath, animated: true)
     
        
    }
    
    func configureCheckmark (for cell: UITableViewCell,
                             with item: ChecklistItem) {
    
        let label = cell.viewWithTag(1001) as! UILabel
        let label1=cell.viewWithTag(1002) as! UILabel
        label.text = item.text
        label1.text=item.date
        if item.checked{
            label.text = "☑︎"
          
        } else {
            label.text = "◻︎"
        }
       
       
       
        removeLocalNotificationIfIsMarked()
        
        saveChecklistItemsCount()
        saveChecklistItemsMediumPriority()
        saveChecklistItemsLowPriority()
        saveChecklistItemsHighPriority()
    }
    
    func configureText(for cell: UITableViewCell,
                       with item: ChecklistItem) {
        let label = cell.viewWithTag(1000) as! UILabel
        let label1=cell.viewWithTag(1002) as! UILabel
        label.text = item.text
        label1.text=item.date
    }
    
    //Navigation
    
    override func prepare(for segue: UIStoryboardSegue,
                          sender: Any?) {
        // 1
        if segue.identifier == "AddItem" {
            //2
            let controller = segue.destination
                as! ItemDetailViewController
            //3
            controller.delegate = self
        } else if segue.identifier == "EditItem" {
            let controller = segue.destination
                as! ItemDetailViewController
            controller.delegate = self
            
            if let indexPath = tableView.indexPath(
                for: sender as! UITableViewCell){
                if indexPath.section == 0 {
                    controller.itemToEdit = highPr[indexPath.row]
                } else if indexPath.section == 2 {
                    controller.itemToEdit = lowPr[indexPath.row]
                } else{
                    controller.itemToEdit = mediumPr[indexPath.row]
                }
            }
        }
       
    }
    
  
   
    
    override func tableView(_ tableView: UITableView,
                            canMoveRowAt indexPath: IndexPath) -> Bool {
        
        
        return true
    }
    
    override func tableView(_ tableView: UITableView,
                            moveRowAt sourceIndexPath: IndexPath,
                            to destinationIndexPath: IndexPath) {
        
     
        let itemToMove:  ChecklistItem
        
        
        if destinationIndexPath.section == 0 {                                      // HIGH SECTION
            
            if sourceIndexPath.section == 2 {      //LOW
                itemToMove = lowPr[sourceIndexPath.row]
                lowPr.remove(at: sourceIndexPath.row)
                highPr.insert(itemToMove, at: destinationIndexPath.row)
            }
            else  if sourceIndexPath.section == 1 {    // MEDIUm
                itemToMove = mediumPr[sourceIndexPath.row]
                mediumPr.remove(at: sourceIndexPath.row)
                highPr.insert(itemToMove, at: destinationIndexPath.row)
            } else {                                      // HIgh
                itemToMove = highPr[sourceIndexPath.row]
                highPr.remove(at: sourceIndexPath.row)
                highPr.insert(itemToMove, at: destinationIndexPath.row)
            }
        }
        else if destinationIndexPath.section == 2 {                                   //LOW SECTION
            
            if sourceIndexPath.section == 2 {           //LOW
                itemToMove = lowPr[sourceIndexPath.row]
                lowPr.remove(at: sourceIndexPath.row)
                lowPr.insert(itemToMove, at: destinationIndexPath.row)
            }
            else if sourceIndexPath.section == 1 {            //Medium
                itemToMove = mediumPr[sourceIndexPath.row]
                mediumPr.remove(at: sourceIndexPath.row)
                
                lowPr.insert(itemToMove, at: destinationIndexPath.row)
            }
            else if sourceIndexPath.section == 0 {               //High
                itemToMove = highPr[sourceIndexPath.row]
                highPr.remove(at: sourceIndexPath.row)
                lowPr.insert(itemToMove, at: destinationIndexPath.row)
            }
        }
        else {                                                                           //MEDIUM SECTION
            if sourceIndexPath.section == 2 {    //LOW
                itemToMove = lowPr[sourceIndexPath.row]
                lowPr.remove(at: sourceIndexPath.row)
                mediumPr.insert(itemToMove, at: destinationIndexPath.row)
            } else if sourceIndexPath.section == 0 {
                itemToMove = highPr[sourceIndexPath.row]
                highPr.remove(at: sourceIndexPath.row)
                mediumPr.insert(itemToMove, at: destinationIndexPath.row)
            } else {
                itemToMove = mediumPr[sourceIndexPath.row]
                mediumPr.remove(at: sourceIndexPath.row)
                mediumPr.insert(itemToMove, at: destinationIndexPath.row)
            }
        }
        
        saveChecklistItemsHighPriority()
        saveChecklistItemsMediumPriority()
        saveChecklistItemsLowPriority()
        saveChecklistItemsCount()
        
    }
    
    
   
    //DELETE ROWS - swipe to delete
    override func tableView(_ tableView: UITableView,
                            commit editingStyle: UITableViewCellEditingStyle,
                            forRowAt indexPath: IndexPath) {
        //1 Remove the item from the data model
        items.remove(at: indexPath.row)
        if indexPath.section == 0 {
            highPr.remove(at: indexPath.row)
        } else if indexPath.section == 2 {
            lowPr.remove(at: indexPath.row)
        } else {
            mediumPr.remove(at: indexPath.row)
        }
        
        //2 Delete the corresponding row from the table view
        let indexPaths = [indexPath]
        tableView.deleteRows(at: indexPaths, with: .automatic)
        saveChecklistItemsLowPriority()
        saveChecklistItemsMediumPriority()
        saveChecklistItemsHighPriority()
        saveChecklistItemsCount()
        
    }
    
    @IBAction func startEditing(_ sender: Any) {
        isEditing = !isEditing
       
        saveChecklistItemsHighPriority()
        saveChecklistItemsMediumPriority()
        saveChecklistItemsLowPriority()
    }
    
    //MARK:- DELETE SELECTED ROWS ---- EDIT BUTTON
    
    @IBAction func deleteRows(_ sender: Any) {
        if let selectedRows = tableView.indexPathsForSelectedRows {
            
            let sortedRows = selectedRows.sorted { $0.row > $1.row }
            
            for selectedRow in sortedRows {
                
                if selectedRow.section == 0 {
                    
                    
                    highPr.remove(at: selectedRow.row)
                    items.remove(at: selectedRow.row)
                    
                } else if selectedRow.section == 2 {
                    
                    lowPr.remove(at: selectedRow.row)
                    items.remove(at: selectedRow.row)
                    
                } else if selectedRow.section == 1 {
                    
                    mediumPr.remove(at: selectedRow.row)
                    items.remove(at: selectedRow.row)
                }
            }
            
            tableView.beginUpdates()
            tableView.deleteRows(at: selectedRows, with: .automatic)
            tableView.endUpdates()
            
        }
        saveChecklistItemsLowPriority()
        saveChecklistItemsMediumPriority()
        saveChecklistItemsHighPriority()
        saveChecklistItemsCount()
       
        
    }
    
    //MARK: -> SAVE DATA
    func documentsDirectory() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return paths[0]
    }
    
   func dataFilePath() -> URL {  //MediumPriority
        return documentsDirectory().appendingPathComponent("ChecklistsMedium.plist")
    }
    func dataFilePathHigh() -> URL {    //HighPriority
        return documentsDirectory().appendingPathComponent("ChecklistsHigh.plist")
    }
    func dataFilePathLow() -> URL {   //LowPriority
        return documentsDirectory().appendingPathComponent("ChecklistsLow.plist")
    }
    
    func dataFilePathCount() -> URL { // ITEMS
        return documentsDirectory().appendingPathComponent("ItemsCount.plist")
    }
    
   func saveChecklistItemsMediumPriority() {
        
        let encoder = PropertyListEncoder()
        do {
            let data = try encoder.encode(mediumPr)
            
            try data.write(to: dataFilePath(),
                           options: Data.WritingOptions.atomic)
            
            
        } catch {
            print("Error encoding item array: \(error.localizedDescription)")
        }
    }
    
    func saveChecklistItemsHighPriority() {
        let encoder = PropertyListEncoder()
        do {
            let data1 = try encoder.encode(highPr)
            
            try data1.write(to: dataFilePathHigh(),
                            options: Data.WritingOptions.atomic)
            
        } catch {
            print("Error encoding item array: \(error.localizedDescription)")
        }
    }
    func saveChecklistItemsLowPriority () {
        let encoder = PropertyListEncoder()
        do {
            let data2 = try encoder.encode(lowPr)
            // LOW PRIORITY SAVE
            try data2.write(to: dataFilePathLow(),
                            options: Data.WritingOptions.atomic)
            
        } catch {
            print("Error encoding item array: \(error.localizedDescription)")
        }
    }
    

  func saveChecklistItemsCount() {
       let encoder = PropertyListEncoder()
        do {
        let data1 = try encoder.encode(items)

           try data1.write(to: dataFilePathCount(),
                         options: Data.WritingOptions.atomic)

      } catch {
          print("Error encoding item array: \(error.localizedDescription)")
        
    }
   }

    // LOADING FILES
   func loadChecklistItemsMediumPriority() {
        let path = dataFilePath()
        if let data = try? Data(contentsOf: path) {
            
            let decoder = PropertyListDecoder()
            do {
                
                
                mediumPr = try decoder.decode([ChecklistItem].self, from: data)
                
            }
            catch {
                print("Error decoding item array: \(error.localizedDescription)")
            }
        }
    }
    
    func loadChecklistItemsHighPriority() {
        let path = dataFilePathHigh()
        if let data1 = try? Data(contentsOf: path) {
            
            let decoder = PropertyListDecoder()
            do {
                highPr = try decoder.decode([ChecklistItem].self, from: data1)
                
            }
            catch {
                print("Error decoding item array: \(error.localizedDescription)")
            }
        }
    }
    
    func loadChecklistItemsLowPriority() {
        let path = dataFilePathLow()
        if let data2 = try? Data(contentsOf: path) {
            
            let decoder = PropertyListDecoder()
            do {
                lowPr = try decoder.decode([ChecklistItem].self, from: data2)
                
            }
            catch {
                print("Error decoding item array: \(error.localizedDescription)")
            }
        }
    }
    func loadChecklistItemsCount() {
        let path = dataFilePathCount()
        if let data1 = try? Data(contentsOf: path) {
            
            let decoder = PropertyListDecoder()
            do {
                items = try decoder.decode([ChecklistItem].self, from: data1)
                
            }
            catch {
                print("Error decoding item array: \(error.localizedDescription)")
            }
        }
    }
    
    
    
}

