

import UIKit

protocol itemDetailViewControllerDelegate: class {
    
    func itemDetailViewControllerDidCancel(_ controller: ItemDetailViewController)
    func itemDetailViewController(_ controller: ItemDetailViewController,didFInishAdding item: ChecklistItem)
    func itemDetailViewController(_ controller: ItemDetailViewController,didFinishEditing item: ChecklistItem)
}


class ItemDetailViewController: UITableViewController {
    
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var doneBarButton: UIBarButtonItem!
    @IBOutlet weak var textFieldDate: UITextField!
    
    private var datePicker:UIDatePicker?
    
    weak var delegate: itemDetailViewControllerDelegate?
    var itemToEdit: ChecklistItem?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        initiateDatePicker()
        
        if let item = itemToEdit {
            title = "Edit item"
            textField.text = item.text
            textFieldDate.text=item.date
            doneBarButton.isEnabled = true
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        textField.becomeFirstResponder()
        textFieldDate.becomeFirstResponder()
    }
    
    func initiateDatePicker() {
        datePicker = UIDatePicker()
        datePicker?.datePickerMode = .dateAndTime
        datePicker?.addTarget(self, action: #selector(ItemDetailViewController.dateChanged(datePicker:)), for: .valueChanged)
        _=UITapGestureRecognizer(target: self, action: #selector(ItemDetailViewController.viewTapped(gestureRecognizer:)))
        textFieldDate.inputView=datePicker
    }
    
    //MARK:- ACTIONS
    @IBAction func cancel() {
        delegate?.itemDetailViewControllerDidCancel(self)
    }
    
    @IBAction func done() {
        if let item = itemToEdit {
            
            item.text = textField.text!
            item.date = textFieldDate.text!
            delegate?.itemDetailViewController(self, didFinishEditing: item)
        } else {
            let item = ChecklistItem()
            item.text = textField.text!
            item.date = textFieldDate.text!
            item.rDate = datePicker?.date
            delegate?.itemDetailViewController(self, didFInishAdding: item)
        }
    }
    
    @objc func dateChanged(datePicker:UIDatePicker){
        let dateFormatter=DateFormatter()
        dateFormatter.dateFormat="MM/dd/yyyy HH:mm"
        textFieldDate.text=dateFormatter.string(from: datePicker.date)
        view.endEditing(true)
    }
    
    @objc func viewTapped(gestureRecognizer:UITapGestureRecognizer){
        view.endEditing(true)
    }
}

//MARK:- Text Field Delegates
extension ItemDetailViewController : UITextFieldDelegate {
    
    func textField(_ textField: UITextField,
                   shouldChangeCharactersIn range: NSRange,
                   replacementString string: String) -> Bool {
        let oldText = textField.text!
        let oldDate=textField.text!
        let stringRange = Range(range, in:oldText)!
        let dateRange=Range(range,in:oldDate)!
        let newText = oldText.replacingCharacters(in: stringRange,
                                                  with: string)
        let newDate=oldDate.replacingCharacters(in: dateRange, with: string)
        if (newText.isEmpty) && (newDate.isEmpty){
            doneBarButton.isEnabled = false
        } else {
            doneBarButton.isEnabled = true
        }
        return true
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        doneBarButton.isEnabled = false
        return true
    }
}
